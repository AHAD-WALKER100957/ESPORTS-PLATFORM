import React, { useEffect, useState } from 'react';
import { games } from '../data/games';
import { tournaments } from '../data/tournaments';
import { news } from '../data/news';
import { teams } from '../data/teams';
import { Game } from '../types';
import { SectionHeading } from '../components/SectionHeading';
import { NewsCard } from '../components/NewsCard';
import { TournamentCard } from '../components/TournamentCard';
import { TeamCard } from '../components/TeamCard';
import { ChevronLeft } from 'lucide-react';

interface GameDetailsProps {
  gameId: string;
  navigateTo: (page: string, id?: string) => void;
}

export const GameDetails: React.FC<GameDetailsProps> = ({ gameId, navigateTo }) => {
  const [game, setGame] = useState<Game | null>(null);
  const [gameNews, setGameNews] = useState<any[]>([]);
  const [gameTournaments, setGameTournaments] = useState<any[]>([]);
  const [gameTeams, setGameTeams] = useState<any[]>([]);

  useEffect(() => {
    const selectedGame = games.find(g => g.id === gameId);
    if (selectedGame) {
      setGame(selectedGame);
      
      // Filter related data
      setGameNews(news.filter(n => n.game === gameId));
      setGameTournaments(tournaments.filter(t => t.game === gameId));
      setGameTeams(teams.filter(t => t.game === gameId));
      
      // Update document title
      document.title = `${selectedGame.name} | Esports Platform`;
    }
  }, [gameId]);

  if (!game) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse-slow">Loading game details...</div>
      </div>
    );
  }

  return (
    <div>
      {/* Hero Section */}
      <div 
        className="relative h-[70vh] bg-cover bg-center flex items-end"
        style={{ backgroundImage: `url(${game.banner})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-valorant-black via-valorant-black/70 to-transparent"></div>
        
        <div className="container mx-auto px-4 relative z-10 pb-12">
          <button 
            onClick={() => navigateTo('home')}
            className="inline-flex items-center text-valorant-gray mb-6 hover:text-valorant-red transition-colors group"
          >
            <ChevronLeft size={20} className="mr-1 transform transition-transform group-hover:-translate-x-1" />
            Back to Home
          </button>
          
          <h1 className={`font-valorant text-5xl md:text-6xl lg:text-7xl uppercase tracking-wider mb-4 text-${game.color}`}>
            {game.name}
          </h1>
          
          <div className="flex flex-wrap gap-3 mb-6">
            {game.genre.map((genre, index) => (
              <span key={index} className="bg-valorant-black/60 px-3 py-1 text-sm">
                {genre}
              </span>
            ))}
            {game.platforms.map((platform, index) => (
              <span key={index} className="bg-valorant-black/60 px-3 py-1 text-sm">
                {platform}
              </span>
            ))}
            {game.esportsTitle && (
              <span className={`bg-${game.color} text-valorant-black px-3 py-1 text-sm font-semibold`}>
                Esports Title
              </span>
            )}
          </div>
          
          <p className="text-lg max-w-2xl">
            {game.shortDescription}
          </p>
        </div>
      </div>
      
      {/* Game Info Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <SectionHeading title="About the Game" />
            <div className="prose prose-invert max-w-none">
              <p className="text-lg">{game.description}</p>
              
              <h3 className="font-valorant text-xl uppercase tracking-wider mt-8 mb-4">Game Features</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className={`text-${game.color} mr-2`}>•</span>
                  <span>Competitive 5v5 gameplay with precise gunplay and tactical abilities</span>
                </li>
                <li className="flex items-start">
                  <span className={`text-${game.color} mr-2`}>•</span>
                  <span>Regular updates with new maps, agents, and game modes</span>
                </li>
                <li className="flex items-start">
                  <span className={`text-${game.color} mr-2`}>•</span>
                  <span>Robust ranking system from Iron to Radiant</span>
                </li>
                <li className="flex items-start">
                  <span className={`text-${game.color} mr-2`}>•</span>
                  <span>Global esports scene with regular tournaments and championships</span>
                </li>
              </ul>
            </div>
            
            <div className="mt-12">
              <a 
                href={game.officialWebsite} 
                target="_blank" 
                rel="noopener noreferrer" 
                className={`inline-block bg-${game.color} text-valorant-black font-valorant py-3 px-8 uppercase tracking-wider hover:bg-opacity-90 transition-colors`}
              >
                Official Website
              </a>
            </div>
          </div>
          
          <div className="bg-valorant-blue p-6 h-fit">
            <h3 className="font-valorant text-xl uppercase tracking-wider mb-6">Game Information</h3>
            
            <div className="space-y-4">
              <div>
                <h4 className="text-sm uppercase tracking-wider text-valorant-gray/60 mb-1">Publisher</h4>
                <p>{game.publisher}</p>
              </div>
              
              <div>
                <h4 className="text-sm uppercase tracking-wider text-valorant-gray/60 mb-1">Release Year</h4>
                <p>{game.releaseYear}</p>
              </div>
              
              <div>
                <h4 className="text-sm uppercase tracking-wider text-valorant-gray/60 mb-1">Platforms</h4>
                <p>{game.platforms.join(', ')}</p>
              </div>
              
              <div>
                <h4 className="text-sm uppercase tracking-wider text-valorant-gray/60 mb-1">Genre</h4>
                <p>{game.genre.join(', ')}</p>
              </div>
              
              <div>
                <h4 className="text-sm uppercase tracking-wider text-valorant-gray/60 mb-1">Player Count</h4>
                <p>{game.playerCount}</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Game Tournaments */}
      {gameTournaments.length > 0 && (
        <section className="py-16 bg-valorant-blue/20">
          <div className="container mx-auto px-4">
            <SectionHeading 
              title={`${game.name} Tournaments`} 
              subtitle={`Upcoming and ongoing tournaments for ${game.name}`}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {gameTournaments.map(tournament => (
                <TournamentCard key={tournament.id} tournament={tournament} />
              ))}
            </div>
          </div>
        </section>
      )}
      
      {/* Game Teams */}
      {gameTeams.length > 0 && (
        <section className="py-16">
          <div className="container mx-auto px-4">
            <SectionHeading 
              title={`Top ${game.name} Teams`} 
              subtitle={`Leading professional teams competing in ${game.name}`}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {gameTeams.map(team => (
                <TeamCard key={team.id} team={team} />
              ))}
            </div>
          </div>
        </section>
      )}
      
      {/* Game News */}
      {gameNews.length > 0 && (
        <section className="py-16 bg-valorant-blue/20">
          <div className="container mx-auto px-4">
            <SectionHeading 
              title={`Latest ${game.name} News`} 
              subtitle={`Stay updated with the latest ${game.name} news and updates`}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {gameNews.map(item => (
                <NewsCard 
                  key={item.id} 
                  news={item} 
                  onClick={() => navigateTo('news-detail', item.id)} 
                />
              ))}
            </div>
          </div>
        </section>
      )}
      
      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <SectionHeading 
            title={`Join the ${game.name} Community`}
            alignment="center"
          />
          
          <div className="max-w-2xl mx-auto">
            <p className="text-lg mb-8">
              Connect with other players, stay updated with the latest news, and never miss a tournament.
            </p>
            
            <div className="flex flex-wrap justify-center gap-4">
              <button className={`bg-${game.color} text-valorant-black font-valorant py-3 px-8 uppercase tracking-wider hover:bg-opacity-90 transition-colors`}>
                Join Community
              </button>
              <button className="border border-valorant-gray font-valorant py-3 px-8 uppercase tracking-wider hover:border-valorant-red hover:text-valorant-red transition-colors">
                Follow for Updates
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};