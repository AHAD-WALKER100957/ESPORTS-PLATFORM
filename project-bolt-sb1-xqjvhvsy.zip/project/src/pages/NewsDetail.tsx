import React, { useEffect, useState } from 'react';
import { news } from '../data/news';
import { NewsCard } from '../components/NewsCard';
import { ChevronLeft } from 'lucide-react';

interface NewsDetailProps {
  newsId: string;
  navigateTo: (page: string, id?: string) => void;
}

export const NewsDetail: React.FC<NewsDetailProps> = ({ newsId, navigateTo }) => {
  const [newsItem, setNewsItem] = useState<any | null>(null);
  const [relatedNews, setRelatedNews] = useState<any[]>([]);
  
  useEffect(() => {
    const selectedNews = news.find(n => n.id === newsId);
    if (selectedNews) {
      setNewsItem(selectedNews);
      
      // Get related news (same game or category, excluding current)
      const related = news
        .filter(n => n.id !== newsId && (n.game === selectedNews.game || n.category === selectedNews.category))
        .slice(0, 3);
      
      setRelatedNews(related);
      
      // Update document title
      document.title = `${selectedNews.title} | Esports Platform`;
    }
  }, [newsId]);
  
  if (!newsItem) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse-slow">Loading news...</div>
      </div>
    );
  }
  
  return (
    <div>
      {/* Hero Section */}
      <div 
        className="relative h-[50vh] bg-cover bg-center flex items-end"
        style={{ backgroundImage: `url(${newsItem.image})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-valorant-black via-valorant-black/80 to-transparent"></div>
        
        <div className="container mx-auto px-4 relative z-10 pb-12">
          <button 
            onClick={() => navigateTo('news')}
            className="inline-flex items-center text-valorant-gray mb-6 hover:text-valorant-red transition-colors group"
          >
            <ChevronLeft size={20} className="mr-1 transform transition-transform group-hover:-translate-x-1" />
            Back to News
          </button>
          
          <div className="flex items-center space-x-4 mb-4">
            <span className="bg-valorant-red px-3 py-1 text-xs uppercase tracking-wider text-valorant-black font-valorant">
              {newsItem.category}
            </span>
            <span className="text-valorant-gray/60">{newsItem.date}</span>
          </div>
          
          <h1 className="font-valorant text-4xl md:text-5xl uppercase tracking-wider mb-4 max-w-3xl">
            {newsItem.title}
          </h1>
        </div>
      </div>
      
      {/* News Content */}
      <section className="py-16 container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <div className="prose prose-invert max-w-none">
              <p className="text-xl font-semibold mb-6">{newsItem.excerpt}</p>
              
              <p className="mb-6">{newsItem.content}</p>
              
              <p className="mb-6">
                The competitive scene continues to evolve with new strategies emerging and meta shifts changing how the game is played at the highest level. Professional teams are constantly adapting to these changes, creating an exciting dynamic for spectators and players alike.
              </p>
              
              <p className="mb-6">
                The community response has been overwhelmingly positive, with social media buzzing about the implications for both casual and competitive play. Content creators have already begun producing tutorials and analysis videos explaining how these changes will affect different skill levels.
              </p>
              
              <p>
                As the esports ecosystem grows, these developments represent an important milestone in the game's evolution. Players and fans alike can look forward to an exciting future with more content, competitions, and opportunities on the horizon.
              </p>
            </div>
            
            <div className="mt-12 pt-8 border-t border-valorant-gray/20">
              <h3 className="font-valorant text-xl uppercase tracking-wider mb-4">Share This Article</h3>
              <div className="flex space-x-4">
                <button className="bg-[#1877F2] text-white p-2 rounded-sm hover:opacity-90 transition-opacity">
                  Facebook
                </button>
                <button className="bg-[#1DA1F2] text-white p-2 rounded-sm hover:opacity-90 transition-opacity">
                  Twitter
                </button>
                <button className="bg-[#0A66C2] text-white p-2 rounded-sm hover:opacity-90 transition-opacity">
                  LinkedIn
                </button>
                <button className="bg-valorant-gray/20 text-valorant-gray p-2 rounded-sm hover:bg-valorant-gray/30 transition-colors">
                  Copy Link
                </button>
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-valorant-blue p-6 sticky top-28">
              <h3 className="font-valorant text-xl uppercase tracking-wider mb-6">Related News</h3>
              
              <div className="space-y-6">
                {relatedNews.length > 0 ? (
                  relatedNews.map(item => (
                    <div 
                      key={item.id}
                      onClick={() => navigateTo('news-detail', item.id)}
                      className="group cursor-pointer"
                    >
                      <div className="overflow-hidden h-32 mb-3">
                        <img 
                          src={item.image} 
                          alt={item.title} 
                          className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
                        />
                      </div>
                      <h4 className="font-valorant text-sm uppercase tracking-wider group-hover:text-valorant-red transition-colors line-clamp-2">
                        {item.title}
                      </h4>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-valorant-red">
                          {item.category}
                        </span>
                        <span className="text-xs text-valorant-gray/60">
                          {item.date}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-valorant-gray/60">No related news available.</p>
                )}
              </div>
              
              <div className="mt-8 pt-6 border-t border-valorant-gray/20">
                <h3 className="font-valorant text-lg uppercase tracking-wider mb-4">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-valorant-black px-3 py-1 text-xs">
                    {newsItem.game}
                  </span>
                  <span className="bg-valorant-black px-3 py-1 text-xs">
                    {newsItem.category}
                  </span>
                  <span className="bg-valorant-black px-3 py-1 text-xs">
                    Esports
                  </span>
                  <span className="bg-valorant-black px-3 py-1 text-xs">
                    Gaming
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* More News Section */}
      <section className="py-16 bg-valorant-blue/20">
        <div className="container mx-auto px-4">
          <h2 className="font-valorant text-3xl uppercase tracking-wider mb-10">
            More News
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {news
              .filter(n => n.id !== newsId)
              .slice(0, 3)
              .map(item => (
                <NewsCard 
                  key={item.id} 
                  news={item} 
                  onClick={() => navigateTo('news-detail', item.id)} 
                />
              ))}
          </div>
        </div>
      </section>
    </div>
  );
};