import React, { useState } from 'react';
import { teams } from '../data/teams';
import { TeamCard } from '../components/TeamCard';
import { SectionHeading } from '../components/SectionHeading';

interface TeamsProps {
  navigateTo: (page: string) => void;
}

export const Teams: React.FC<TeamsProps> = ({ navigateTo }) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  
  const games = ['all', ...new Set(teams.map(item => item.game))];
  
  const filteredTeams = teams.filter(item => {
    if (activeFilter === 'all') return true;
    return item.game === activeFilter;
  });
  
  return (
    <div>
      {/* Hero Section */}
      <div className="relative py-32 bg-valorant-black">
        <div className="absolute inset-0 opacity-20">
          <div className="h-full w-full bg-hero-pattern bg-cover bg-center"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="font-valorant text-5xl md:text-6xl uppercase tracking-wider mb-6">
            Professional <span className="text-valorant-red">Teams</span>
          </h1>
          <p className="text-lg max-w-xl mx-auto">
            Discover the top esports organizations, their rosters, achievements, and latest performance statistics.
          </p>
        </div>
      </div>
      
      {/* Team Filters */}
      <div className="bg-valorant-blue sticky top-16 z-20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="font-valorant uppercase tracking-wider text-sm mr-2">
              Filter By Game:
            </div>
            
            <div className="flex flex-wrap gap-2">
              {games.map(game => (
                <button 
                  key={game}
                  onClick={() => setActiveFilter(game)}
                  className={`px-3 py-1 text-sm uppercase transition-colors ${activeFilter === game ? 'bg-valorant-red text-valorant-black' : 'bg-valorant-black hover:bg-valorant-black/70'}`}
                >
                  {game === 'all' ? 'All Games' : game}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* Teams Grid */}
      <section className="py-16 container mx-auto px-4">
        <SectionHeading 
          title={activeFilter === 'all' ? 'All Teams' : `${activeFilter} Teams`}
          subtitle={`Showing ${filteredTeams.length} professional teams`}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTeams.map(team => (
            <TeamCard key={team.id} team={team} />
          ))}
        </div>
        
        {filteredTeams.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg">No teams found matching your filter criteria.</p>
            <button 
              onClick={() => setActiveFilter('all')}
              className="mt-4 text-valorant-red hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </section>
      
      {/* Team Rankings */}
      <section className="py-16 bg-valorant-blue/20">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Global Rankings"
            subtitle="Current standings of the top teams across different games"
          />
          
          <div className="space-y-8">
            <div>
              <h3 className="font-valorant text-xl uppercase tracking-wider mb-4">
                VALORANT Rankings
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-valorant-black">
                    <tr>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Rank</th>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Team</th>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Region</th>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Points</th>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Change</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-valorant-gray/10">
                    <tr className="bg-valorant-blue/60">
                      <td className="p-4">1</td>
                      <td className="p-4">Sentinels</td>
                      <td className="p-4">North America</td>
                      <td className="p-4">1200</td>
                      <td className="p-4 text-green-500">↑2</td>
                    </tr>
                    <tr className="bg-valorant-blue/30">
                      <td className="p-4">2</td>
                      <td className="p-4">Fnatic</td>
                      <td className="p-4">Europe</td>
                      <td className="p-4">1150</td>
                      <td className="p-4 text-red-500">↓1</td>
                    </tr>
                    <tr className="bg-valorant-blue/60">
                      <td className="p-4">3</td>
                      <td className="p-4">DRX</td>
                      <td className="p-4">Korea</td>
                      <td className="p-4">1050</td>
                      <td className="p-4 text-red-500">↓1</td>
                    </tr>
                    <tr className="bg-valorant-blue/30">
                      <td className="p-4">4</td>
                      <td className="p-4">LOUD</td>
                      <td className="p-4">Brazil</td>
                      <td className="p-4">980</td>
                      <td className="p-4">-</td>
                    </tr>
                    <tr className="bg-valorant-blue/60">
                      <td className="p-4">5</td>
                      <td className="p-4">Paper Rex</td>
                      <td className="p-4">Southeast Asia</td>
                      <td className="p-4">925</td>
                      <td className="p-4 text-green-500">↑3</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            
            <div>
              <h3 className="font-valorant text-xl uppercase tracking-wider mb-4">
                Counter-Strike 2 Rankings
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-valorant-black">
                    <tr>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Rank</th>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Team</th>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Region</th>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Points</th>
                      <th className="p-4 text-sm font-valorant uppercase tracking-wider">Change</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-valorant-gray/10">
                    <tr className="bg-valorant-blue/60">
                      <td className="p-4">1</td>
                      <td className="p-4">Team Vitality</td>
                      <td className="p-4">France</td>
                      <td className="p-4">1300</td>
                      <td className="p-4 text-green-500">↑1</td>
                    </tr>
                    <tr className="bg-valorant-blue/30">
                      <td className="p-4">2</td>
                      <td className="p-4">Team Liquid</td>
                      <td className="p-4">North America</td>
                      <td className="p-4">1250</td>
                      <td className="p-4 text-red-500">↓1</td>
                    </tr>
                    <tr className="bg-valorant-blue/60">
                      <td className="p-4">3</td>
                      <td className="p-4">FaZe Clan</td>
                      <td className="p-4">International</td>
                      <td className="p-4">1180</td>
                      <td className="p-4">-</td>
                    </tr>
                    <tr className="bg-valorant-blue/30">
                      <td className="p-4">4</td>
                      <td className="p-4">Natus Vincere</td>
                      <td className="p-4">Ukraine</td>
                      <td className="p-4">1120</td>
                      <td className="p-4">-</td>
                    </tr>
                    <tr className="bg-valorant-blue/60">
                      <td className="p-4">5</td>
                      <td className="p-4">G2 Esports</td>
                      <td className="p-4">Europe</td>
                      <td className="p-4">1050</td>
                      <td className="p-4 text-green-500">↑2</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Team Registration CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <SectionHeading 
            title="Join the Professional Circuit"
            subtitle="Register your team to compete in official tournaments and be featured on our platform."
            alignment="center"
          />
          
          <div className="max-w-lg mx-auto">
            <button className="bg-valorant-red text-valorant-black font-valorant py-3 px-8 hover:bg-valorant-red/90 transition-colors uppercase tracking-wider">
              Register Team
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};