import React, { useEffect, useRef } from 'react';
import { games } from '../data/games';
import { news } from '../data/news';
import { tournaments } from '../data/tournaments';
import { teams } from '../data/teams';
import { GameCard } from '../components/GameCard';
import { NewsCard } from '../components/NewsCard';
import { TournamentCard } from '../components/TournamentCard';
import { TeamCard } from '../components/TeamCard';
import { SectionHeading } from '../components/SectionHeading';
import { ChevronRight } from 'lucide-react';

interface HomeProps {
  navigateTo: (page: string, id?: string) => void;
}

export const Home: React.FC<HomeProps> = ({ navigateTo }) => {
  const heroRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleScroll = () => {
      const heroElement = heroRef.current;
      if (!heroElement) return;
      
      const scrollPosition = window.scrollY;
      const heroHeight = heroElement.offsetHeight;
      const parallaxFactor = 0.5;
      
      if (scrollPosition <= heroHeight) {
        const translateY = scrollPosition * parallaxFactor;
        heroElement.style.transform = `translateY(${translateY}px)`;
        heroElement.style.opacity = `${1 - (scrollPosition / heroHeight) * 0.8}`;
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-screen overflow-hidden">
        <div 
          ref={heroRef}
          className="absolute inset-0 bg-valorant-bg bg-cover bg-center"
        ></div>
        <div className="absolute inset-0 bg-gradient-to-b from-valorant-black/80 to-valorant-black"></div>
        
        <div className="relative h-full flex flex-col justify-center container mx-auto px-4 z-10">
          <div className="max-w-3xl">
            <h1 className="font-valorant text-4xl md:text-6xl lg:text-7xl uppercase tracking-wider leading-tight mb-6 animate-fade-in">
              Welcome to <span className="text-valorant-red">Esports</span> Platform
            </h1>
            <p className="text-valorant-gray/90 text-lg md:text-xl max-w-xl mb-8 animate-slide-in">
              Your premier destination for competitive gaming news, tournaments, and team information. Follow your favorite games and players all in one place.
            </p>
            <div className="flex flex-wrap gap-4 animate-fade-in">
              <button 
                onClick={() => navigateTo('tournaments')}
                className="bg-valorant-red text-valorant-black font-valorant py-3 px-8 hover:bg-valorant-red/90 transition-colors uppercase tracking-wider"
              >
                Explore Tournaments
              </button>
              <button 
                onClick={() => navigateTo('news')}
                className="border border-valorant-red text-valorant-red font-valorant py-3 px-8 hover:bg-valorant-red/10 transition-colors uppercase tracking-wider"
              >
                Latest News
              </button>
            </div>
          </div>
          
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-valorant-red" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </div>
      </div>
      
      {/* Featured Games Section */}
      <section className="py-20 container mx-auto px-4">
        <SectionHeading
          title="Featured Games"
          subtitle="Explore the top competitive titles in esports, from tactical shooters to battle royales."
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {games.map(game => (
            <GameCard 
              key={game.id} 
              game={game} 
              onClick={() => navigateTo('game-details', game.id)} 
            />
          ))}
        </div>
      </section>
      
      {/* Latest News Section */}
      <section className="py-20 bg-valorant-blue/20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-10">
            <SectionHeading
              title="Latest News"
              subtitle="Stay updated with the latest happenings in the esports world."
            />
            
            <button 
              onClick={() => navigateTo('news')}
              className="inline-flex items-center text-valorant-red font-valorant uppercase tracking-wider hover:underline group mt-4 md:mt-0"
            >
              View All News
              <ChevronRight size={16} className="ml-1 transform transition-transform group-hover:translate-x-1" />
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {news.slice(0, 3).map(item => (
              <NewsCard 
                key={item.id} 
                news={item} 
                onClick={() => navigateTo('news-detail', item.id)} 
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Upcoming Tournaments */}
      <section className="py-20 container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-10">
          <SectionHeading
            title="Upcoming Tournaments"
            subtitle="Don't miss the action in these premier esports competitions."
          />
          
          <button 
            onClick={() => navigateTo('tournaments')}
            className="inline-flex items-center text-valorant-red font-valorant uppercase tracking-wider hover:underline group mt-4 md:mt-0"
          >
            View All Tournaments
            <ChevronRight size={16} className="ml-1 transform transition-transform group-hover:translate-x-1" />
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tournaments.slice(0, 3).map(tournament => (
            <TournamentCard key={tournament.id} tournament={tournament} />
          ))}
        </div>
      </section>
      
      {/* Featured Teams */}
      <section className="py-20 bg-valorant-blue/20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-10">
            <SectionHeading
              title="Top Teams"
              subtitle="Get to know the elite organizations competing at the highest level."
            />
            
            <button 
              onClick={() => navigateTo('teams')}
              className="inline-flex items-center text-valorant-red font-valorant uppercase tracking-wider hover:underline group mt-4 md:mt-0"
            >
              View All Teams
              <ChevronRight size={16} className="ml-1 transform transition-transform group-hover:translate-x-1" />
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {teams.slice(0, 4).map(team => (
              <TeamCard key={team.id} team={team} />
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-24 bg-valorant-bg bg-cover bg-center relative">
        <div className="absolute inset-0 bg-valorant-black/80"></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h2 className="font-valorant text-4xl md:text-5xl uppercase tracking-wider mb-6 max-w-3xl mx-auto">
            Ready to Elevate Your <span className="text-valorant-red">Esports</span> Experience?
          </h2>
          <p className="text-valorant-gray/90 text-lg max-w-2xl mx-auto mb-8">
            Join our community to get personalized updates on your favorite games, teams, and tournaments. Never miss a match again.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="bg-valorant-red text-valorant-black font-valorant py-3 px-8 hover:bg-valorant-red/90 transition-colors uppercase tracking-wider">
              Sign Up Now
            </button>
            <button className="bg-transparent border border-valorant-gray text-valorant-gray font-valorant py-3 px-8 hover:border-valorant-red hover:text-valorant-red transition-colors uppercase tracking-wider">
              Learn More
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};