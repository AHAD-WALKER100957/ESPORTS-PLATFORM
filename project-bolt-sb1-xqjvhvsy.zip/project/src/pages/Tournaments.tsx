import React, { useState } from 'react';
import { tournaments } from '../data/tournaments';
import { TournamentCard } from '../components/TournamentCard';
import { SectionHeading } from '../components/SectionHeading';

interface TournamentsProps {
  navigateTo: (page: string) => void;
}

export const Tournaments: React.FC<TournamentsProps> = ({ navigateTo }) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  
  const games = ['all', ...new Set(tournaments.map(item => item.game))];
  const statuses = ['all', ...new Set(tournaments.map(item => item.status))];
  
  const filteredTournaments = tournaments.filter(item => {
    if (activeFilter === 'all') return true;
    return item.game === activeFilter || item.status === activeFilter;
  });
  
  return (
    <div>
      {/* Hero Section */}
      <div className="relative py-32 bg-valorant-black">
        <div className="absolute inset-0 opacity-20">
          <div className="h-full w-full bg-hero-pattern bg-cover bg-center"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="font-valorant text-5xl md:text-6xl uppercase tracking-wider mb-6">
            Esports <span className="text-valorant-red">Tournaments</span>
          </h1>
          <p className="text-lg max-w-xl mx-auto">
            Explore upcoming and ongoing esports tournaments from around the world featuring top teams and massive prize pools.
          </p>
        </div>
      </div>
      
      {/* Tournament Filters */}
      <div className="bg-valorant-blue sticky top-16 z-20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="font-valorant uppercase tracking-wider text-sm mr-2">
              Filter By:
            </div>
            
            <div className="flex flex-wrap gap-2">
              {games.map(game => (
                <button 
                  key={game}
                  onClick={() => setActiveFilter(game)}
                  className={`px-3 py-1 text-sm uppercase transition-colors ${activeFilter === game ? 'bg-valorant-red text-valorant-black' : 'bg-valorant-black hover:bg-valorant-black/70'}`}
                >
                  {game === 'all' ? 'All Games' : game}
                </button>
              ))}
            </div>
            
            <div className="h-8 w-px bg-valorant-gray/20 mx-2"></div>
            
            <div className="flex flex-wrap gap-2">
              {statuses.map(status => (
                <button 
                  key={status}
                  onClick={() => setActiveFilter(status)}
                  className={`px-3 py-1 text-sm uppercase transition-colors ${activeFilter === status ? 'bg-valorant-red text-valorant-black' : 'bg-valorant-black hover:bg-valorant-black/70'}`}
                >
                  {status === 'all' ? 'All Statuses' : status}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* Tournaments Grid */}
      <section className="py-16 container mx-auto px-4">
        <SectionHeading 
          title={activeFilter === 'all' ? 'All Tournaments' : `${activeFilter} Tournaments`}
          subtitle={`Showing ${filteredTournaments.length} tournaments`}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTournaments.map(tournament => (
            <TournamentCard key={tournament.id} tournament={tournament} />
          ))}
        </div>
        
        {filteredTournaments.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg">No tournaments found matching your filter criteria.</p>
            <button 
              onClick={() => setActiveFilter('all')}
              className="mt-4 text-valorant-red hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </section>
      
      {/* Calendar Section */}
      <section className="py-16 bg-valorant-blue/20">
        <div className="container mx-auto px-4">
          <SectionHeading 
            title="Tournament Calendar"
            subtitle="Plan ahead with our comprehensive tournament schedule"
          />
          
          <div className="bg-valorant-blue p-6">
            <div className="flex flex-wrap justify-between items-center mb-6">
              <h3 className="font-valorant text-xl uppercase tracking-wider">November 2024</h3>
              <div className="flex space-x-2">
                <button className="bg-valorant-black p-2 hover:bg-valorant-black/70 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <button className="bg-valorant-black p-2 hover:bg-valorant-black/70 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-7 gap-2 text-center mb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="text-valorant-gray/60 text-sm py-2">
                  {day}
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-7 gap-2">
              {Array.from({ length: 30 }, (_, i) => i + 1).map(day => {
                const hasEvent = Math.random() > 0.7;
                return (
                  <div 
                    key={day}
                    className={`aspect-square flex flex-col items-center justify-center p-1 text-sm border border-valorant-gray/10 hover:border-valorant-red/30 transition-colors ${hasEvent ? 'bg-valorant-black cursor-pointer' : ''}`}
                  >
                    <span>{day}</span>
                    {hasEvent && (
                      <div className="w-1.5 h-1.5 bg-valorant-red rounded-full mt-1"></div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>
      
      {/* Tournament Registration CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <SectionHeading 
            title="Register Your Tournament"
            subtitle="Are you organizing an esports tournament? List it on our platform to reach a wider audience."
            alignment="center"
          />
          
          <div className="max-w-lg mx-auto">
            <button className="bg-valorant-red text-valorant-black font-valorant py-3 px-8 hover:bg-valorant-red/90 transition-colors uppercase tracking-wider">
              Submit Tournament
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};