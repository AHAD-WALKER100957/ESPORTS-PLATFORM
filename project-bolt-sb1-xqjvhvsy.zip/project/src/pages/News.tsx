import React, { useState } from 'react';
import { news } from '../data/news';
import { NewsCard } from '../components/NewsCard';
import { SectionHeading } from '../components/SectionHeading';

interface NewsProps {
  navigateTo: (page: string, id?: string) => void;
}

export const News: React.FC<NewsProps> = ({ navigateTo }) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  
  const categories = ['all', ...new Set(news.map(item => item.category))];
  const games = ['all', ...new Set(news.map(item => item.game))];
  
  const filteredNews = news.filter(item => {
    if (activeFilter === 'all') return true;
    return item.category === activeFilter || item.game === activeFilter;
  });
  
  return (
    <div>
      {/* Hero Section */}
      <div className="relative py-32 bg-valorant-black">
        <div className="absolute inset-0 opacity-20">
          <div className="h-full w-full bg-hero-pattern bg-cover bg-center"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="font-valorant text-5xl md:text-6xl uppercase tracking-wider mb-6">
            Latest <span className="text-valorant-red">Esports</span> News
          </h1>
          <p className="text-lg max-w-xl mx-auto">
            Stay updated with the latest news, updates, and announcements from the world of competitive gaming.
          </p>
        </div>
      </div>
      
      {/* News Filters */}
      <div className="bg-valorant-blue sticky top-16 z-20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="font-valorant uppercase tracking-wider text-sm mr-2">
              Filter By:
            </div>
            
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <button 
                  key={category}
                  onClick={() => setActiveFilter(category)}
                  className={`px-3 py-1 text-sm uppercase transition-colors ${activeFilter === category ? 'bg-valorant-red text-valorant-black' : 'bg-valorant-black hover:bg-valorant-black/70'}`}
                >
                  {category}
                </button>
              ))}
            </div>
            
            <div className="h-8 w-px bg-valorant-gray/20 mx-2"></div>
            
            <div className="flex flex-wrap gap-2">
              {games.map(game => (
                <button 
                  key={game}
                  onClick={() => setActiveFilter(game)}
                  className={`px-3 py-1 text-sm uppercase transition-colors ${activeFilter === game ? 'bg-valorant-red text-valorant-black' : 'bg-valorant-black hover:bg-valorant-black/70'}`}
                >
                  {game === 'all' ? 'All Games' : game}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* News Grid */}
      <section className="py-16 container mx-auto px-4">
        <SectionHeading 
          title={activeFilter === 'all' ? 'All News' : `${activeFilter} News`}
          subtitle={`Showing ${filteredNews.length} news articles`}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNews.map(item => (
            <NewsCard 
              key={item.id} 
              news={item} 
              onClick={() => navigateTo('news-detail', item.id)} 
            />
          ))}
        </div>
        
        {filteredNews.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg">No news articles found matching your filter criteria.</p>
            <button 
              onClick={() => setActiveFilter('all')}
              className="mt-4 text-valorant-red hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </section>
      
      {/* Newsletter Section */}
      <section className="py-16 bg-valorant-blue/20">
        <div className="container mx-auto px-4 text-center">
          <SectionHeading 
            title="Stay Updated"
            subtitle="Subscribe to our newsletter to receive the latest esports news straight to your inbox."
            alignment="center"
          />
          
          <div className="max-w-md mx-auto">
            <form className="flex flex-col sm:flex-row gap-3">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-grow bg-valorant-black border border-valorant-gray/30 text-valorant-gray px-4 py-3 focus:outline-none focus:border-valorant-red transition-colors"
              />
              <button 
                type="submit" 
                className="bg-valorant-red text-valorant-black font-valorant py-3 px-6 hover:bg-valorant-red/90 transition-colors uppercase tracking-wider whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>
            <p className="text-sm text-valorant-gray/60 mt-3">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};