import { Tournament } from '../types';

export const tournaments: Tournament[] = [
  {
    id: '1',
    name: 'VALORANT Champions 2025',
    game: 'valorant',
    startDate: '2025-08-15',
    endDate: '2025-09-05',
    location: 'Seoul, South Korea',
    prize: '$2,000,000',
    teams: ['Sentinels', 'Fnatic', 'DRX', 'Paper Rex', 'LOUD', 'Team Liquid', 'Evil Geniuses', 'FunPlus Phoenix'],
    status: 'upcoming',
    image: 'https://images.pexels.com/photos/7915585/pexels-photo-7915585.jpeg'
  },
  {
    id: '2',
    name: 'CS2 Major Stockholm',
    game: 'csgo',
    startDate: '2025-06-10',
    endDate: '2025-06-23',
    location: 'Stockholm, Sweden',
    prize: '$1,250,000',
    teams: ['Natus Vincere', 'FaZe Clan', 'Team Vitality', 'G2 Esports', 'Astralis', 'Team Liquid', 'ENCE', 'Heroic'],
    status: 'upcoming',
    image: 'https://images.pexels.com/photos/3945683/pexels-photo-3945683.jpeg'
  },
  {
    id: '3',
    name: 'BGMI Pro League Season 5',
    game: 'bgmi',
    startDate: '2025-01-15',
    endDate: '2025-02-28',
    location: 'Bangalore, India',
    prize: '₹2,00,00,000',
    teams: ['Soul', 'GodLike Esports', 'Team XSpark', 'Orangutan', 'Global Esports', 'Team SouL', 'Enigma Gaming', 'Revenant Esports'],
    status: 'upcoming',
    image: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg'
  },
  {
    id: '4',
    name: 'Call of Duty League Championship 2025',
    game: 'cod',
    startDate: '2025-07-25',
    endDate: '2025-08-02',
    location: 'Los Angeles, USA',
    prize: '$1,500,000',
    teams: ['Atlanta FaZe', 'OpTic Texas', 'Seattle Surge', 'Los Angeles Thieves', 'New York Subliners', 'Toronto Ultra', 'Minnesota RØKKR', 'Boston Breach'],
    status: 'upcoming',
    image: 'https://images.pexels.com/photos/2007647/pexels-photo-2007647.jpeg'
  },
  {
    id: '5',
    name: 'VALORANT Masters Tokyo',
    game: 'valorant',
    startDate: '2025-03-10',
    endDate: '2025-03-24',
    location: 'Tokyo, Japan',
    prize: '$700,000',
    teams: ['Zeta Division', 'DRX', 'Paper Rex', 'Team Liquid', 'Fnatic', 'Evil Geniuses', 'LOUD', 'Gen.G'],
    status: 'upcoming',
    image: 'https://images.pexels.com/photos/7915387/pexels-photo-7915387.jpeg'
  },
  {
    id: '6',
    name: 'BGMI India Series 2025',
    game: 'bgmi',
    startDate: '2025-04-05',
    endDate: '2025-05-10',
    location: 'Mumbai, India',
    prize: '₹1,50,00,000',
    teams: ['Team SouL', 'GodLike Esports', 'Team XSpark', 'Orangutan', 'Global Esports', 'Revenant Esports', 'Enigma Gaming', 'Team 8Bit'],
    status: 'upcoming',
    image: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg'
  }
];