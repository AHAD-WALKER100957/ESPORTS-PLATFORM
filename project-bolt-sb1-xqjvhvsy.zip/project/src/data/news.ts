import { NewsItem } from '../types';

export const news: NewsItem[] = [
  {
    id: '1',
    title: 'VALORANT Champions Tour 2025 Announced with $2M Prize Pool',
    excerpt: 'Riot Games has unveiled the details for the 2025 VALORANT Champions Tour with the largest prize pool yet.',
    content: 'Riot Games has officially announced the 2025 VALORANT Champions Tour, featuring a record-breaking $2 million prize pool. The tournament will include teams from all major regions, with qualifiers beginning in February. This year introduces a new format with additional international LAN events and expanded opportunities for tier-two teams to advance to the top level of competition.',
    date: '2024-11-15',
    image: 'https://images.pexels.com/photos/7915521/pexels-photo-7915521.jpeg',
    category: 'Tournament',
    game: 'valorant'
  },
  {
    id: '2',
    title: 'Counter-Strike 2 Major Championship Breaks Viewership Records',
    excerpt: 'The latest CS2 Major has shattered all previous viewership records with over 1.5 million concurrent viewers.',
    content: 'The recent Counter-Strike 2 Major Championship has set new records in esports viewership, with peak concurrent viewers exceeding 1.5 million across all platforms. The grand final between Team Liquid and Natus Vincere was particularly notable, becoming the most-watched CS2 match in history. Analysts attribute this growth to the game\'s successful transition from CS:GO to CS2 and expanding global interest in tactical shooters.',
    date: '2024-11-10',
    image: 'https://images.pexels.com/photos/3945683/pexels-photo-3945683.jpeg',
    category: 'Esports',
    game: 'csgo'
  },
  {
    id: '3',
    title: 'BGMI Pro League Season 5 Announced with Increased Regional Qualifiers',
    excerpt: 'Krafton expands the BGMI Pro League with additional regional qualifiers and a revamped tournament structure.',
    content: 'Krafton has announced the fifth season of the BGMI Pro League, featuring an expanded format with additional regional qualifiers across India. The tournament will now include six regional qualifiers instead of four, giving more teams the opportunity to compete at the highest level. The prize pool has been increased to ₹2 crore, making it the largest BGMI tournament to date. The main event will be held in Bangalore with a live audience for the playoffs and grand finals.',
    date: '2024-11-05',
    image: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg',
    category: 'Tournament',
    game: 'bgmi'
  },
  {
    id: '4',
    title: 'Call of Duty League 2025 Introduces New Team-Based Format',
    excerpt: 'The CDL is revamping its format for the 2025 season with an emphasis on team-based competition and regional rivalries.',
    content: 'Activision has unveiled significant changes to the Call of Duty League for the 2025 season, introducing a new team-based format designed to highlight regional rivalries and create more compelling narratives throughout the season. The traditional home-and-away structure will be supplemented with regional tournaments, and the points system has been overhauled to place greater emphasis on consistent performance rather than single event results. Additionally, the league will feature expanded content creation opportunities for teams and players to better connect with their fanbases.',
    date: '2024-11-01',
    image: 'https://images.pexels.com/photos/2007647/pexels-photo-2007647.jpeg',
    category: 'Esports',
    game: 'cod'
  },
  {
    id: '5',
    title: 'New VALORANT Agent Teased for Episode 8',
    excerpt: 'Riot Games has begun teasing a new controller agent coming in Episode 8 with unique smoke mechanics.',
    content: 'Riot Games has started teasing a new VALORANT agent scheduled to arrive with Episode 8. According to early hints scattered across the game\'s maps and social media, the agent will be a controller with innovative smoke mechanics that can adapt based on terrain. Community speculation suggests the agent may be from South America, further expanding the game\'s global representation. A full reveal is expected in the coming weeks, with the agent likely hitting the test servers before the end of the year.',
    date: '2024-10-28',
    image: 'https://images.pexels.com/photos/7915585/pexels-photo-7915585.jpeg',
    category: 'Game Update',
    game: 'valorant'
  },
  {
    id: '6',
    title: 'BGMI 3.0 Update Brings New Map and Gameplay Mechanics',
    excerpt: 'The latest major update for Battlegrounds Mobile India introduces a new urban map and overhauled movement mechanics.',
    content: 'Krafton has released the BGMI 3.0 update, introducing a brand new urban map called "Nexus" featuring dense city environments with vertical gameplay opportunities. The update also includes significant changes to the movement system, adding new parkour mechanics such as wall-running and improved vaulting. Additionally, the weapon balance has been adjusted with several firearms receiving buffs and nerfs based on community feedback. The update is available now and has already seen positive reception from players and content creators alike.',
    date: '2024-10-20',
    image: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg',
    category: 'Game Update',
    game: 'bgmi'
  }
];