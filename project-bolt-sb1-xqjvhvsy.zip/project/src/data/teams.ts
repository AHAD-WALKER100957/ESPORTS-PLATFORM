import { Team } from '../types';

export const teams: Team[] = [
  {
    id: '1',
    name: 'Sentinels',
    logo: 'https://images.pexels.com/photos/6476587/pexels-photo-6476587.jpeg',
    country: 'United States',
    game: 'valorant',
    players: [
      {
        id: 'p1',
        name: 'Tyson Ngo',
        nickname: 'TenZ',
        image: 'https://images.pexels.com/photos/7915478/pexels-photo-7915478.jpeg',
        team: 'Sentinels',
        role: 'Duelist',
        country: 'Canada',
        statistics: {
          kills: 4350,
          deaths: 3100,
          assists: 1250,
          kda: 1.8
        }
      },
      {
        id: 'p2',
        name: 'Shahzeb Khan',
        nickname: 'ShahZaM',
        image: 'https://images.pexels.com/photos/7915571/pexels-photo-7915571.jpeg',
        team: 'Sentinels',
        role: 'Initiator',
        country: 'United States',
        statistics: {
          kills: 3900,
          deaths: 3300,
          assists: 2100,
          kda: 1.82
        }
      }
    ],
    achievements: [
      'VCT 2021 Stage 2 Masters - 1st Place',
      'VCT 2021 NA Stage 1 Masters - 1st Place',
      'VCT 2023 Americas League - 4th Place'
    ],
    ranking: 3
  },
  {
    id: '2',
    name: 'Team Liquid',
    logo: 'https://images.pexels.com/photos/6476595/pexels-photo-6476595.jpeg',
    country: 'Netherlands',
    game: 'csgo',
    players: [
      {
        id: 'p3',
        name: 'Jonathan Jablonowski',
        nickname: 'EliGE',
        image: 'https://images.pexels.com/photos/7915433/pexels-photo-7915433.jpeg',
        team: 'Team Liquid',
        role: 'Rifler',
        country: 'United States',
        statistics: {
          kills: 24350,
          deaths: 21100,
          assists: 5250,
          kda: 1.4
        }
      },
      {
        id: 'p4',
        name: 'Keith Markovic',
        nickname: 'NAF',
        image: 'https://images.pexels.com/photos/7915484/pexels-photo-7915484.jpeg',
        team: 'Team Liquid',
        role: 'Rifler',
        country: 'Canada',
        statistics: {
          kills: 23900,
          deaths: 20300,
          assists: 6100,
          kda: 1.48
        }
      }
    ],
    achievements: [
      'Intel Grand Slam Season 2 Winner',
      'ESL Pro League Season 9 - 1st Place',
      'IEM Chicago 2019 - 1st Place'
    ],
    ranking: 2
  },
  {
    id: '3',
    name: 'Team SouL',
    logo: 'https://images.pexels.com/photos/6476589/pexels-photo-6476589.jpeg',
    country: 'India',
    game: 'bgmi',
    players: [
      {
        id: 'p5',
        name: 'Naman Mathur',
        nickname: 'Mortal',
        image: 'https://images.pexels.com/photos/7915523/pexels-photo-7915523.jpeg',
        team: 'Team SouL',
        role: 'IGL',
        country: 'India',
        statistics: {
          kills: 5350,
          deaths: 2100,
          assists: 3250,
          kda: 4.1
        }
      },
      {
        id: 'p6',
        name: 'Yash Soni',
        nickname: 'Viper',
        image: 'https://images.pexels.com/photos/7915599/pexels-photo-7915599.jpeg',
        team: 'Team SouL',
        role: 'Assaulter',
        country: 'India',
        statistics: {
          kills: 6900,
          deaths: 3300,
          assists: 2100,
          kda: 2.73
        }
      }
    ],
    achievements: [
      'BMPS 2022 Season 1 - 1st Place',
      'BGMI Masters Series 2022 - 3rd Place',
      'PMIS 2019 - 1st Place'
    ],
    ranking: 1
  },
  {
    id: '4',
    name: 'Atlanta FaZe',
    logo: 'https://images.pexels.com/photos/6476601/pexels-photo-6476601.jpeg',
    country: 'United States',
    game: 'cod',
    players: [
      {
        id: 'p7',
        name: 'Chris Lehr',
        nickname: 'Simp',
        image: 'https://images.pexels.com/photos/7915428/pexels-photo-7915428.jpeg',
        team: 'Atlanta FaZe',
        role: 'SMG',
        country: 'United States',
        statistics: {
          kills: 15350,
          deaths: 12100,
          assists: 4250,
          kda: 1.62
        }
      },
      {
        id: 'p8',
        name: 'Tyler Pharris',
        nickname: 'aBeZy',
        image: 'https://images.pexels.com/photos/7915562/pexels-photo-7915562.jpeg',
        team: 'Atlanta FaZe',
        role: 'SMG',
        country: 'United States',
        statistics: {
          kills: 14900,
          deaths: 13300,
          assists: 5100,
          kda: 1.5
        }
      }
    ],
    achievements: [
      'CDL Championship 2021 - 1st Place',
      'CDL Major II 2021 - 1st Place',
      'CDL Major III 2021 - 1st Place'
    ],
    ranking: 1
  }
];