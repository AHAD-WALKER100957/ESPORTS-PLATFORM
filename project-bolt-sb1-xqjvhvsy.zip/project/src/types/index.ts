export interface Game {
  id: string;
  name: string;
  logo: string;
  banner: string;
  description: string;
  publisher: string;
  releaseYear: number;
  platforms: string[];
  genre: string[];
  playerCount: string;
  esportsTitle: boolean;
  officialWebsite: string;
  color: string;
  shortDescription: string;
}

export interface NewsItem {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  image: string;
  category: string;
  game: string;
}

export interface Tournament {
  id: string;
  name: string;
  game: string;
  startDate: string;
  endDate: string;
  location: string;
  prize: string;
  teams: string[];
  status: 'upcoming' | 'ongoing' | 'completed';
  image: string;
}

export interface Team {
  id: string;
  name: string;
  logo: string;
  country: string;
  game: string;
  players: Player[];
  achievements: string[];
  ranking: number;
}

export interface Player {
  id: string;
  name: string;
  nickname: string;
  image: string;
  team: string;
  role: string;
  country: string;
  statistics: {
    kills: number;
    deaths: number;
    assists: number;
    kda: number;
  };
}