import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { GameDetails } from './pages/GameDetails';
import { News } from './pages/News';
import { Tournaments } from './pages/Tournaments';
import { Teams } from './pages/Teams';
import { NewsDetail } from './pages/NewsDetail';
import { AnimatedBackground } from './components/AnimatedBackground';
import { PageTransition } from './components/PageTransition';

function App() {
  const [page, setPage] = useState<string>('home');
  const [gameId, setGameId] = useState<string | null>(null);
  const [newsId, setNewsId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const navigateTo = (targetPage: string, id?: string) => {
    setIsLoading(true);
    setTimeout(() => {
      setPage(targetPage);
      if (targetPage === 'game-details' && id) {
        setGameId(id);
      } else if (targetPage === 'news-detail' && id) {
        setNewsId(id);
      }
      setIsLoading(false);
    }, 800);
  };

  const renderPage = () => {
    switch (page) {
      case 'home':
        return <Home navigateTo={navigateTo} />;
      case 'game-details':
        return <GameDetails gameId={gameId || ''} navigateTo={navigateTo} />;
      case 'news':
        return <News navigateTo={navigateTo} />;
      case 'news-detail':
        return <NewsDetail newsId={newsId || ''} navigateTo={navigateTo} />;
      case 'tournaments':
        return <Tournaments navigateTo={navigateTo} />;
      case 'teams':
        return <Teams navigateTo={navigateTo} />;
      default:
        return <Home navigateTo={navigateTo} />;
    }
  };

  return (
    <div className="min-h-screen bg-valorant-black text-valorant-gray font-din relative overflow-hidden">
      {isLoading ? (
        <PageTransition />
      ) : (
        <>
          <AnimatedBackground />
          <Header navigateTo={navigateTo} currentPage={page} />
          <main className="relative z-10">
            {renderPage()}
          </main>
          <Footer navigateTo={navigateTo} />
        </>
      )}
    </div>
  );
}

export default App;