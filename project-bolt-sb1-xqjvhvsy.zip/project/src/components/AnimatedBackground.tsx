import React, { useEffect } from 'react';

export const AnimatedBackground: React.FC = () => {
  useEffect(() => {
    const createParticles = () => {
      const particlesContainer = document.getElementById('particles-container');
      if (!particlesContainer) return;
      
      // Clear existing particles
      particlesContainer.innerHTML = '';
      
      const numberOfParticles = Math.min(window.innerWidth / 10, 100);
      
      for (let i = 0; i < numberOfParticles; i++) {
        const particle = document.createElement('div');
        
        // Random position
        const posX = Math.random() * window.innerWidth;
        const posY = Math.random() * window.innerHeight;
        
        // Random size
        const size = Math.random() * 3 + 1;
        
        // Random opacity
        const opacity = Math.random() * 0.5 + 0.1;
        
        // Random animation duration
        const duration = Math.random() * 20 + 10;
        
        // Apply styles
        particle.style.cssText = `
          position: absolute;
          width: ${size}px;
          height: ${size}px;
          background-color: rgba(255, 70, 85, ${opacity});
          left: ${posX}px;
          top: ${posY}px;
          animation: float ${duration}s infinite linear;
          border-radius: 50%;
          z-index: 1;
        `;
        
        particlesContainer.appendChild(particle);
      }
    };
    
    // Create particles initially
    createParticles();
    
    // Re-create on resize
    window.addEventListener('resize', createParticles);
    
    return () => {
      window.removeEventListener('resize', createParticles);
    };
  }, []);
  
  return (
    <>
      <div id="particles-container" className="fixed inset-0 pointer-events-none overflow-hidden" />
      <div className="fixed inset-0 bg-gradient-to-b from-valorant-black to-valorant-blue/30 pointer-events-none z-0" />
      
      <style jsx>{`
        @keyframes float {
          0% {
            transform: translateY(0) translateX(0) rotate(0deg);
          }
          25% {
            transform: translateY(-20px) translateX(10px) rotate(90deg);
          }
          50% {
            transform: translateY(-40px) translateX(0) rotate(180deg);
          }
          75% {
            transform: translateY(-20px) translateX(-10px) rotate(270deg);
          }
          100% {
            transform: translateY(0) translateX(0) rotate(360deg);
          }
        }
      `}</style>
    </>
  );
};