import React from 'react';
import { Logo } from './Logo';
import { Facebook, Twitter, Instagram, Youtube, Twitch } from 'lucide-react';

interface FooterProps {
  navigateTo: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ navigateTo }) => {
  return (
    <footer className="bg-valorant-blue relative z-10 mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <Logo onClick={() => navigateTo('home')} />
            <p className="mt-4 text-sm text-valorant-gray/80">
              The premier destination for esports enthusiasts. Follow your favorite games, teams, and tournaments all in one place.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="text-valorant-gray/80 hover:text-valorant-red transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-valorant-gray/80 hover:text-valorant-red transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-valorant-gray/80 hover:text-valorant-red transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-valorant-gray/80 hover:text-valorant-red transition-colors">
                <Youtube size={20} />
              </a>
              <a href="#" className="text-valorant-gray/80 hover:text-valorant-red transition-colors">
                <Twitch size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-valorant text-lg uppercase tracking-wider mb-4">Games</h3>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => navigateTo('game-details', 'valorant')} 
                  className="text-valorant-gray/80 hover:text-valorant-red transition-colors"
                >
                  VALORANT
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateTo('game-details', 'csgo')} 
                  className="text-valorant-gray/80 hover:text-valorant-red transition-colors"
                >
                  Counter-Strike 2
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateTo('game-details', 'bgmi')} 
                  className="text-valorant-gray/80 hover:text-valorant-red transition-colors"
                >
                  Battlegrounds Mobile India
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateTo('game-details', 'cod')} 
                  className="text-valorant-gray/80 hover:text-valorant-red transition-colors"
                >
                  Call of Duty: Warzone
                </button>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-valorant text-lg uppercase tracking-wider mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => navigateTo('news')} 
                  className="text-valorant-gray/80 hover:text-valorant-red transition-colors"
                >
                  News
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateTo('tournaments')} 
                  className="text-valorant-gray/80 hover:text-valorant-red transition-colors"
                >
                  Tournaments
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateTo('teams')} 
                  className="text-valorant-gray/80 hover:text-valorant-red transition-colors"
                >
                  Teams
                </button>
              </li>
              <li>
                <a href="#" className="text-valorant-gray/80 hover:text-valorant-red transition-colors">About</a>
              </li>
              <li>
                <a href="#" className="text-valorant-gray/80 hover:text-valorant-red transition-colors">Contact</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-valorant text-lg uppercase tracking-wider mb-4">Newsletter</h3>
            <p className="text-sm text-valorant-gray/80 mb-4">
              Subscribe to our newsletter to receive the latest esports news and updates.
            </p>
            <form className="space-y-3">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="w-full bg-valorant-black border border-valorant-gray/30 text-valorant-gray px-3 py-2 focus:outline-none focus:border-valorant-red transition-colors"
              />
              <button 
                type="submit" 
                className="w-full bg-valorant-red text-valorant-black font-valorant py-2 hover:bg-valorant-red/90 transition-colors uppercase tracking-wider text-sm"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-valorant-gray/20 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-valorant-gray/60">
            © 2025 Esports Platform. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-sm text-valorant-gray/60 hover:text-valorant-red transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-sm text-valorant-gray/60 hover:text-valorant-red transition-colors">
              Terms of Service
            </a>
            <a href="#" className="text-sm text-valorant-gray/60 hover:text-valorant-red transition-colors">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};