import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Logo } from './Logo';

interface HeaderProps {
  navigateTo: (page: string, id?: string) => void;
  currentPage: string;
}

export const Header: React.FC<HeaderProps> = ({ navigateTo, currentPage }) => {
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [isScrolled, setIsScrolled] = useState<boolean>(false);
  const [dropdownOpen, setDropdownOpen] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleDropdown = (dropdown: string) => {
    if (dropdownOpen === dropdown) {
      setDropdownOpen(null);
    } else {
      setDropdownOpen(dropdown);
    }
  };

  const handleNavigation = (page: string, id?: string) => {
    navigateTo(page, id);
    setIsMenuOpen(false);
    setDropdownOpen(null);
  };

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-valorant-black/90 backdrop-blur-md py-3' : 'bg-transparent py-5'}`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <Logo onClick={() => handleNavigation('home')} />
          <nav className="hidden lg:flex ml-10">
            <ul className="flex space-x-8">
              <li className="relative group">
                <button 
                  onClick={() => toggleDropdown('games')} 
                  className={`flex items-center font-valorant text-lg uppercase tracking-wider hover:text-valorant-red transition-colors ${currentPage === 'game-details' ? 'text-valorant-red' : ''}`}
                >
                  Games <ChevronDown size={16} className="ml-1" />
                </button>
                <div className={`absolute left-0 mt-2 w-56 origin-top-left transition-all duration-300 ${dropdownOpen === 'games' ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                  <div className="bg-valorant-blue border border-valorant-red/20 shadow-lg shadow-valorant-red/10 rounded-sm py-2">
                    <button 
                      onClick={() => handleNavigation('game-details', 'valorant')} 
                      className="block w-full text-left px-4 py-2 hover:bg-valorant-red/10 font-din text-sm"
                    >
                      VALORANT
                    </button>
                    <button 
                      onClick={() => handleNavigation('game-details', 'csgo')} 
                      className="block w-full text-left px-4 py-2 hover:bg-valorant-red/10 font-din text-sm"
                    >
                      Counter-Strike 2
                    </button>
                    <button 
                      onClick={() => handleNavigation('game-details', 'bgmi')} 
                      className="block w-full text-left px-4 py-2 hover:bg-valorant-red/10 font-din text-sm"
                    >
                      BGMI
                    </button>
                    <button 
                      onClick={() => handleNavigation('game-details', 'cod')} 
                      className="block w-full text-left px-4 py-2 hover:bg-valorant-red/10 font-din text-sm"
                    >
                      Call of Duty
                    </button>
                  </div>
                </div>
              </li>
              <li>
                <button 
                  onClick={() => handleNavigation('news')} 
                  className={`font-valorant text-lg uppercase tracking-wider hover:text-valorant-red transition-colors ${currentPage === 'news' || currentPage === 'news-detail' ? 'text-valorant-red' : ''}`}
                >
                  News
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleNavigation('tournaments')} 
                  className={`font-valorant text-lg uppercase tracking-wider hover:text-valorant-red transition-colors ${currentPage === 'tournaments' ? 'text-valorant-red' : ''}`}
                >
                  Tournaments
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleNavigation('teams')} 
                  className={`font-valorant text-lg uppercase tracking-wider hover:text-valorant-red transition-colors ${currentPage === 'teams' ? 'text-valorant-red' : ''}`}
                >
                  Teams
                </button>
              </li>
            </ul>
          </nav>
        </div>
        
        <div className="hidden lg:flex items-center space-x-4">
          <button className="bg-valorant-red text-valorant-black font-valorant py-2 px-6 hover:bg-valorant-red/90 transition-colors uppercase tracking-wider text-sm">
            Sign In
          </button>
        </div>
        
        <button 
          className="lg:hidden text-valorant-gray hover:text-valorant-red transition-colors"
          onClick={toggleMenu}
        >
          <Menu size={24} />
        </button>
      </div>
      
      {/* Mobile menu */}
      <div className={`fixed inset-0 bg-valorant-black z-50 transform transition-transform duration-300 ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="container mx-auto px-4 py-5 flex justify-between items-center">
          <Logo onClick={() => handleNavigation('home')} />
          <button 
            className="text-valorant-gray hover:text-valorant-red transition-colors"
            onClick={toggleMenu}
          >
            <X size={24} />
          </button>
        </div>
        <nav className="container mx-auto px-4 py-8">
          <ul className="space-y-6">
            <li>
              <button 
                onClick={() => toggleDropdown('mobile-games')} 
                className="flex items-center justify-between w-full font-valorant text-2xl uppercase tracking-wider"
              >
                Games <ChevronDown size={20} className={`transition-transform ${dropdownOpen === 'mobile-games' ? 'rotate-180' : ''}`} />
              </button>
              <div className={`mt-2 space-y-2 pl-4 transition-all duration-300 ${dropdownOpen === 'mobile-games' ? 'h-auto opacity-100' : 'h-0 opacity-0 overflow-hidden'}`}>
                <button 
                  onClick={() => handleNavigation('game-details', 'valorant')} 
                  className="block w-full text-left py-2 font-din"
                >
                  VALORANT
                </button>
                <button 
                  onClick={() => handleNavigation('game-details', 'csgo')} 
                  className="block w-full text-left py-2 font-din"
                >
                  Counter-Strike 2
                </button>
                <button 
                  onClick={() => handleNavigation('game-details', 'bgmi')} 
                  className="block w-full text-left py-2 font-din"
                >
                  BGMI
                </button>
                <button 
                  onClick={() => handleNavigation('game-details', 'cod')} 
                  className="block w-full text-left py-2 font-din"
                >
                  Call of Duty
                </button>
              </div>
            </li>
            <li>
              <button 
                onClick={() => handleNavigation('news')} 
                className="font-valorant text-2xl uppercase tracking-wider"
              >
                News
              </button>
            </li>
            <li>
              <button 
                onClick={() => handleNavigation('tournaments')} 
                className="font-valorant text-2xl uppercase tracking-wider"
              >
                Tournaments
              </button>
            </li>
            <li>
              <button 
                onClick={() => handleNavigation('teams')} 
                className="font-valorant text-2xl uppercase tracking-wider"
              >
                Teams
              </button>
            </li>
          </ul>
          <div className="mt-10 pt-6 border-t border-valorant-gray/20">
            <button className="bg-valorant-red text-valorant-black font-valorant py-3 px-6 w-full hover:bg-valorant-red/90 transition-colors uppercase tracking-wider">
              Sign In
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
};