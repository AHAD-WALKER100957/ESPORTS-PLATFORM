import React from 'react';
import { NewsItem } from '../types';

interface NewsCardProps {
  news: NewsItem;
  onClick: () => void;
}

export const NewsCard: React.FC<NewsCardProps> = ({ news, onClick }) => {
  return (
    <div 
      className="group cursor-pointer bg-valorant-blue border border-valorant-gray/10 hover:border-valorant-red/20 transition-all duration-300 overflow-hidden"
      onClick={onClick}
    >
      <div className="overflow-hidden h-48">
        <img 
          src={news.image} 
          alt={news.title} 
          className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      
      <div className="p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs uppercase tracking-wider text-valorant-red font-din">
            {news.category}
          </span>
          <span className="text-xs text-valorant-gray/60 font-din">
            {news.date}
          </span>
        </div>
        
        <h3 className="font-valorant text-lg uppercase tracking-wider mb-2 line-clamp-2 group-hover:text-valorant-red transition-colors">
          {news.title}
        </h3>
        
        <p className="text-valorant-gray/80 text-sm line-clamp-3 mb-4">
          {news.excerpt}
        </p>
        
        <div className="flex items-center space-x-1 text-valorant-red text-sm font-din">
          <span>Read More</span>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 transform transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>
  );
};