import React from 'react';
import { Team } from '../types';

interface TeamCardProps {
  team: Team;
}

export const TeamCard: React.FC<TeamCardProps> = ({ team }) => {
  return (
    <div className="bg-valorant-blue border border-valorant-gray/10 hover:border-valorant-red/20 transition-all duration-300 group p-5">
      <div className="flex items-center space-x-4 mb-5">
        <div className="w-16 h-16 flex-shrink-0 bg-valorant-black p-2 rounded-sm">
          <img 
            src={team.logo} 
            alt={team.name} 
            className="w-full h-full object-contain"
          />
        </div>
        
        <div>
          <h3 className="font-valorant text-xl uppercase tracking-wider group-hover:text-valorant-red transition-colors">
            {team.name}
          </h3>
          <div className="flex items-center space-x-3 text-sm text-valorant-gray/70">
            <span>{team.country}</span>
            <span>•</span>
            <span>{team.game}</span>
            <span>•</span>
            <span>Rank #{team.ranking}</span>
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <h4 className="text-sm uppercase tracking-wider font-din mb-2">Roster</h4>
        <div className="grid grid-cols-2 gap-3">
          {team.players.map(player => (
            <div key={player.id} className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-valorant-black">
                <img 
                  src={player.image} 
                  alt={player.nickname} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="text-sm font-semibold">{player.nickname}</p>
                <p className="text-xs text-valorant-gray/60">{player.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div>
        <h4 className="text-sm uppercase tracking-wider font-din mb-2">Achievements</h4>
        <ul className="text-sm text-valorant-gray/80 space-y-1">
          {team.achievements.map((achievement, index) => (
            <li key={index} className="flex items-start">
              <span className="text-valorant-red mr-2">•</span>
              <span>{achievement}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};