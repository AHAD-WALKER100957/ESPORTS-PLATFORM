import React from 'react';

interface SectionHeadingProps {
  title: string;
  subtitle?: string;
  alignment?: 'left' | 'center' | 'right';
}

export const SectionHeading: React.FC<SectionHeadingProps> = ({ 
  title, 
  subtitle,
  alignment = 'left'
}) => {
  const alignmentClasses = {
    left: 'text-left',
    center: 'text-center mx-auto',
    right: 'text-right ml-auto'
  };
  
  return (
    <div className={`mb-10 max-w-2xl ${alignmentClasses[alignment]}`}>
      <h2 className="font-valorant text-3xl md:text-4xl lg:text-5xl uppercase tracking-wider relative inline-block">
        {title}
        <div className="absolute -bottom-2 left-0 h-1 w-16 bg-valorant-red"></div>
      </h2>
      {subtitle && (
        <p className="mt-6 text-valorant-gray/80 text-lg">
          {subtitle}
        </p>
      )}
    </div>
  );
};