import React from 'react';
import { Game } from '../types';

interface GameCardProps {
  game: Game;
  onClick: () => void;
}

export const GameCard: React.FC<GameCardProps> = ({ game, onClick }) => {
  return (
    <div 
      className="group relative overflow-hidden rounded-sm cursor-pointer transform transition-transform duration-300 hover:scale-[1.02] hover:shadow-lg hover:shadow-valorant-red/20"
      onClick={onClick}
    >
      <div 
        className="h-80 bg-cover bg-center"
        style={{ backgroundImage: `url(${game.banner})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-valorant-black to-transparent opacity-80 group-hover:opacity-70 transition-opacity"></div>
        
        <div className="absolute bottom-0 left-0 p-5 w-full">
          <h3 className={`font-valorant text-2xl uppercase tracking-wider mb-2 text-${game.color}`}>
            {game.name}
          </h3>
          <p className="text-valorant-gray/90 font-din text-sm line-clamp-2">
            {game.shortDescription}
          </p>
          
          <div className={`mt-4 inline-block bg-${game.color} text-valorant-black font-valorant py-1 px-4 text-sm uppercase tracking-wider group-hover:bg-opacity-90 transition-all transform translate-y-2 group-hover:translate-y-0 opacity-0 group-hover:opacity-100`}>
            View Details
          </div>
        </div>
      </div>
      
      <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className={`h-1 w-24 bg-${game.color}`}></div>
      </div>
      
      <div className="absolute top-0 left-0 w-full h-full border-2 border-transparent group-hover:border-valorant-red/30 transition-all"></div>
    </div>
  );
};