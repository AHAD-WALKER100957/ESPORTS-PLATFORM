import React from 'react';
import { Tournament } from '../types';
import { Calendar, MapPin, Trophy } from 'lucide-react';

interface TournamentCardProps {
  tournament: Tournament;
}

export const TournamentCard: React.FC<TournamentCardProps> = ({ tournament }) => {
  return (
    <div className="bg-valorant-blue border border-valorant-gray/10 hover:border-valorant-red/20 transition-all duration-300 group">
      <div className="relative overflow-hidden h-48">
        <img 
          src={tournament.image} 
          alt={tournament.name} 
          className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-0 left-0 m-3">
          <span className="bg-valorant-red px-3 py-1 text-xs uppercase tracking-wider text-valorant-black font-valorant">
            {tournament.status}
          </span>
        </div>
      </div>
      
      <div className="p-5">
        <h3 className="font-valorant text-xl uppercase tracking-wider mb-3 group-hover:text-valorant-red transition-colors">
          {tournament.name}
        </h3>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-sm text-valorant-gray/80">
            <Calendar size={16} className="mr-2 text-valorant-red" />
            <span>{tournament.startDate} to {tournament.endDate}</span>
          </div>
          
          <div className="flex items-center text-sm text-valorant-gray/80">
            <MapPin size={16} className="mr-2 text-valorant-red" />
            <span>{tournament.location}</span>
          </div>
          
          <div className="flex items-center text-sm text-valorant-gray/80">
            <Trophy size={16} className="mr-2 text-valorant-red" />
            <span>{tournament.prize} Prize Pool</span>
          </div>
        </div>
        
        <div className="pt-4 border-t border-valorant-gray/10">
          <h4 className="text-sm uppercase tracking-wider font-din mb-2">Participating Teams</h4>
          <div className="flex flex-wrap gap-2">
            {tournament.teams.slice(0, 4).map((team, index) => (
              <span 
                key={index} 
                className="bg-valorant-black px-2 py-1 text-xs rounded-sm"
              >
                {team}
              </span>
            ))}
            {tournament.teams.length > 4 && (
              <span className="bg-valorant-black px-2 py-1 text-xs rounded-sm">
                +{tournament.teams.length - 4} more
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};