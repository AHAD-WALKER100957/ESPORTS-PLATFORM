import React from 'react';
import { Logo } from './Logo';

export const PageTransition: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-valorant-black z-50 flex flex-col items-center justify-center">
      <div className="animate-pulse-slow">
        <Logo onClick={() => {}} />
      </div>
      
      <div className="mt-12 w-64 h-1 bg-valorant-black relative overflow-hidden rounded-full">
        <div className="absolute inset-y-0 left-0 bg-valorant-red animate-[loadingBar_2s_ease-in-out_infinite]" style={{ width: '30%' }}></div>
      </div>
      
      <style jsx>{`
        @keyframes loadingBar {
          0% {
            left: -30%;
          }
          50% {
            left: 100%;
          }
          100% {
            left: -30%;
          }
        }
      `}</style>
    </div>
  );
};