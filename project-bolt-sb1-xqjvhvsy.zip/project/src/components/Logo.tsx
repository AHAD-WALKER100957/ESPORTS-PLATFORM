import React from 'react';
import { Gamepad2 } from 'lucide-react';

interface LogoProps {
  onClick: () => void;
}

export const Logo: React.FC<LogoProps> = ({ onClick }) => {
  return (
    <button 
      onClick={onClick}
      className="flex items-center space-x-2 group"
    >
      <div className="bg-valorant-red p-1 rounded-sm transform group-hover:rotate-12 transition-transform">
        <Gamepad2 size={24} className="text-valorant-black" />
      </div>
      <span className="font-valorant text-2xl uppercase tracking-wider group-hover:text-valorant-red transition-colors">
        Esports Platform
      </span>
    </button>
  );
};