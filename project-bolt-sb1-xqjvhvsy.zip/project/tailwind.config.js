/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'valorant-red': '#FF4655',
        'valorant-black': '#0F1923',
        'valorant-gray': '#ECE8E1',
        'valorant-blue': '#1F2326',
        'valorant-dark': '#111111',
        'cod-blue': '#0078F2',
        'csgo-orange': '#DE9B35',
        'bgmi-yellow': '#FFC700',
      },
      fontFamily: {
        'valorant': ['Tungsten', 'sans-serif'],
        'din': ['DIN Next', 'sans-serif'],
      },
      backgroundImage: {
        'hero-pattern': "url('https://images.pexels.com/photos/2747893/pexels-photo-2747893.jpeg')",
        'valorant-bg': "url('https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg')",
        'cod-bg': "url('https://images.pexels.com/photos/2007647/pexels-photo-2007647.jpeg')",
        'csgo-bg': "url('https://images.pexels.com/photos/3945683/pexels-photo-3945683.jpeg')",
        'bgmi-bg': "url('https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg')",
      },
      animation: {
        'glitch': 'glitch 1s linear infinite',
        'slide-in': 'slideIn 0.5s forwards',
        'fade-in': 'fadeIn 0.5s forwards',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        glitch: {
          '0%, 100%': { transform: 'translate(0)' },
          '20%': { transform: 'translate(-5px, 5px)' },
          '40%': { transform: 'translate(-5px, -5px)' },
          '60%': { transform: 'translate(5px, 5px)' },
          '80%': { transform: 'translate(5px, -5px)' },
        },
        slideIn: {
          '0%': { transform: 'translateY(100%)', opacity: 0 },
          '100%': { transform: 'translateY(0)', opacity: 1 },
        },
        fadeIn: {
          '0%': { opacity: 0 },
          '100%': { opacity: 1 },
        },
      },
    },
  },
  plugins: [],
};